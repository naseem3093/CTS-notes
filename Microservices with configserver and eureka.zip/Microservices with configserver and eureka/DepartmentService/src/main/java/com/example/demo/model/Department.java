package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "department_info")
@NoArgsConstructor
@AllArgsConstructor
public class Department {
	@Id
	@Column(name = "deptno")
	private int departmentId;
	private String departmentName;
	private String departmentLocation;
}
