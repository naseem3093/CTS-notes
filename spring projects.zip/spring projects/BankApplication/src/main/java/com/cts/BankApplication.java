package com.cts;

import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cts.model.Account;
import com.cts.service.CustomerService;
import com.cts.service.CustomerServiceImpl;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@SpringBootApplication
public class BankApplication {

    private final CustomerServiceImpl service;

    BankApplication(CustomerServiceImpl service) {
        this.service = service;
    }

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(BankApplication.class, args);
		CustomerService service=context.getBean("service",CustomerService.class);
		 String name;
		 int accNo;
		 long phoneNo;
		 int pin;
	     long balance;
	     int amount;
	     Account account;
	     while (true) {

			System.out.println("1.Save Customer Details");

			System.out.println("2.Update Customer Details");

			System.out.println("3. Get Customer Account Details");

			System.out.println("4. To Withdraw Amount");

			System.out.println("5. To Deposit Amount");
			
			System.out.println("6.Exit");

			Scanner sc = new Scanner(System.in);

			int option = sc.nextInt();

			switch (option) {

			case 1:
                System.out.println("Enter the name :");
                name=sc.next();
                System.out.println("Enter the Phone Number :");
                phoneNo=sc.nextLong();
                System.out.println("Enter the Pin Number :");
                pin=sc.nextInt();
                System.out.println("Enter the Amount :");
                balance=sc.nextLong();
                account=new Account(name,phoneNo,pin,balance);
                System.out.println(service.createAccount(account));
				break;

			case 2:

				System.out.println("Enter the name :");
                name=sc.next();
                System.out.println("Enter the Phone Number :");
                phoneNo=sc.nextLong();
                System.out.println("Enter the Pin Number :");
                pin=sc.nextInt();
                System.out.println("Enter the Amount :");
                balance=sc.nextLong();
                account=new Account(name,phoneNo,pin,balance);
                System.out.println(service.updateAccoutDetails(account));
				break;
			case 3:

				System.out.println("Enter the Account Number");

				accNo = sc.nextInt();

				System.out.println(service.getAccoutDetails(accNo));

				break;

			case 4:

				System.out.println("Enter the Account Number");

				accNo = sc.nextInt();
				System.out.println("Enter the Pin Number");

				pin = sc.nextInt();
				System.out.println("Enter the Amount");

				amount = sc.nextInt();

				System.out.println(service.withdraw(amount, accNo, pin));

				break;

			case 5:

				System.out.println("Enter the Account Number");

				accNo = sc.nextInt();
				System.out.println("Enter the Amount");

				amount = sc.nextInt();

				System.out.println(service.deposit(amount, accNo));

				break;

			
			case 6:

				System.out.println("Thank You !!!!");

				System.exit(1);

				break;

			default:

				break;

			}
		}
	}

}
