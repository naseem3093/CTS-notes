package com.cts.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="account-info")
public class Account {
	private String customerName;
	@Id
	@GeneratedValue
	private int customerAccNo;
	private long customerPhoneNo;
	@Column(name="Pin number")
	private int customerPin;
    private long balance;
	public Account() {
		
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerAccNo() {
		return customerAccNo;
	}

	public long getCustomerPhoneNo() {
		return customerPhoneNo;
	}

	public void setCustomerPhoneNo(long customerPhoneNo) {
		this.customerPhoneNo = customerPhoneNo;
	}

	public int getCustomerPin() {
		return customerPin;
	}

	public void setCustomerPin(int customerPin) {
		this.customerPin = customerPin;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public Account(String customerName, long customerPhoneNo, int customerPin, long balance) {
		super();
		this.customerName = customerName;
		this.customerPhoneNo = customerPhoneNo;
		this.customerPin = customerPin;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [customerName=" + customerName + ", customerAccNo=" + customerAccNo + ", customerPhoneNo="
				+ customerPhoneNo + ", customerPin=" + customerPin + ", balance=" + balance + "]";
	}

}
