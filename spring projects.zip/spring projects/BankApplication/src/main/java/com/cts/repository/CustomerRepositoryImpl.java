package com.cts.repository;

import org.springframework.stereotype.Repository;

import com.cts.model.Account;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
@Repository
@Transactional
public  class CustomerRepositoryImpl implements CustomerRepository{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public String createAccount(Account account) {
		entityManager.persist(account);
		return "Account Saved Successfully";
	}

	@Override
	public Account getAccoutDetails(int customerAccNo) {
		
		return entityManager.find(Account.class,customerAccNo);
	}

	@Override
	public String updateAccoutDetails(Account account) {
		entityManager.merge(account);
		return "Account Saved Successfully";
	}

	@Override
	public String withdraw(int amount, int customerAccNo, int customerPin) {
		Account account=entityManager.find(Account.class,customerAccNo);
		if(account.getCustomerPin()==customerPin) {
		   if(account.getBalance()>=amount) {
			account.setBalance(account.getBalance()-amount);
			entityManager.merge(account);
			return "Amount withdraw Successfully and your current balance is"+account.getBalance(); }
		   else
			  return "Insuffcient Balance";
		}
		else
			return "Invalid Pin number";
	}

	@Override
	public String deposit(int amount, int customerAccNo) {
		   if(amount>=0) {
			Account account=entityManager.find(Account.class,customerAccNo);
			account.setBalance(account.getBalance()+amount);
			entityManager.merge(account);
			return "Amount Added Successfully and your current balance is"+account.getBalance(); }
		   else
			  return "Invalid Amount";
	}

}
