package com.cts.service;

import com.cts.model.Account;

public interface CustomerService {
	public abstract String createAccount(Account account);

	public abstract Account getAccoutDetails(int customerAccNo);

	public abstract String updateAccoutDetails(Account account);

	public abstract String withdraw(int amount, int customerAccNo, int customerPin);

	public abstract String deposit(int amount, int customerAccNo);
}