package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Account;
import com.cts.repository.CustomerRepository;
import com.cts.service.*;
@Service("service")
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepository repository;
	@Override
	public String createAccount(Account account) {
		return repository.createAccount(account);
	}

	@Override
	public Account getAccoutDetails(int customerAccNo) {
		return repository.getAccoutDetails(customerAccNo);
	}


	@Override
	public String withdraw(int amount, int customerAccNo, int customerPin) {
		return repository.withdraw(amount, customerAccNo, customerPin);
	}

	@Override
	public String deposit(int amount, int customerAccNo) {
		return getRepository().deposit(amount, customerAccNo);
	}

	public CustomerRepository getRepository() {
		return repository;
	}

	public void setRepository(CustomerRepository repository) {
		this.repository = repository;
	}

	@Override
	public String updateAccoutDetails(Account account) {
		return repository.updateAccoutDetails(account);
	}

}
