/**
 * 
 */
/**
 * 
 */
module JavaCore {
}