package com.cts.service;

import java.util.List;

import com.cts.model.Product;

public interface ProductService {
	public abstract Product updateProduct(Product product);

	public abstract String removeProduct(int productId);

	public abstract Product getProduct(int productId);

	public abstract List<Product> getAllProduct();

	public abstract List<Product> getAllProductBetween(int initialPrice, int finalPrice);

	public abstract List<Product> getAllProductByCategory(String category);

	public abstract String saveProduct(Product product);

	List<Product> getAllProductsBetween(int initialPrice, int finalPrice);

	List<Product> getAllProductsProductByCategory(String Category);

}
