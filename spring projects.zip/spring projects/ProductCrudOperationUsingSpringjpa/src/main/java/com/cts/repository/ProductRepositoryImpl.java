package com.cts.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.model.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
@Repository
@Transactional
public class ProductRepositoryImpl implements ProductRepository {
//	entitymanager-- persist()--insert,merge()--update,remove()--delete,fetch()--find.
	@PersistenceContext
	EntityManager entityManager ;

	@Override
	public String saveProduct(Product product) {
		// TODO Auto-generated method stub
		
		entityManager.persist(product);
		return "product saved Successfully";
	}

	public String updateProduct(Product product) {
		// TODO Auto-generated method stub
		entityManager.merge(product);
	
		return "product updated Successfully";
	}

	@Override
	public String removeProduct(int productId) {
		entityManager.remove(getProduct(productId));
		return "product removed Successfully";
	}

	@Override
	public Product getProduct(int productId) {

		// TODO Auto-generated method stub
		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProduct() {
		TypedQuery<Product> result= entityManager.createQuery("select p from product p",Product.class);
		// TODO Auto-generated method stub
		return result.getResultList();
	}

	@Override
	public List<Product> getAllProductBetween(int initialPrice, int finalPrice) {
		// TODO Auto-generated method stub
		TypedQuery<Product> result= entityManager.createQuery("select p from product p where p.productPrice between?1 and ?2",Product.class);
		result.setParameter(1, initialPrice);
		result.setParameter(2, finalPrice);
		return result.getResultList();
	}

	@Override
	public List<Product> getAllProductByCategory(String category) {
		TypedQuery<Product> result= entityManager.createQuery("select p from product p where p.productcategory =?1",Product.class);
		result.setParameter(1, category);
		return result.getResultList();
	}

	@Override
	public List<Product> getProductsGraterThanPrice(int price) {
		// TODO Auto-generated method stub
		return null;
	}

}
