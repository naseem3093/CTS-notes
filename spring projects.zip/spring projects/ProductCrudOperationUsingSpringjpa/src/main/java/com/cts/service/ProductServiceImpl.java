package com.cts.service;
 
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Product;
import com.cts.repository.ProductRepository;
import com.cts.repository.ProductRepositoryImpl;
@Service("productService")
 
public class ProductServiceImpl implements ProductService{
	@Autowired
	Logger log=LoggerFactory.getLogger(ProductServiceImpl.class);
	ProductRepository repository;
	public ProductServiceImpl() {
		repository=new ProductRepositoryImpl();
	}
 
	@Override
	public String saveProduct(Product product) {
		log.info("hello hi ");
		return repository.saveProduct(product);
	}
 
	@Override
	public String updateProduct(Product product) {
		// TODO Auto-generated method stub
		return repository.updateProduct(product);
	}
 
	@Override
	public String removeProduct(int productId) {
		// TODO Auto-generated method stub
		return repository.removeProduct(productId);
	}
 
	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return repository.getProduct(productId);
	}
 
	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return repository.getAllProduct();
	}
 
	@Override
	public List<Product> getAllProductsBetween(int initialPrice, int finalPrice) {
		// TODO Auto-generated method stub
		return repository.getAllProductBetween(initialPrice, finalPrice);
	}
 
	@Override
	public List<Product> getAllProductsProductByCategory(String Category) {
		// TODO Auto-generated method stub
		return repository.getAllProductByCategory(Category);
	}

	@Override
	public List<Product> getAllProductBetween(int initialPrice, int finalPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProductByCategory(String category) {
		// TODO Auto-generated method stub
		return null;
	}
 
}