package com.cts;

public class Airtelsim implements Sim{
	
	private float chargesPerMonth;
	
	
	@Override
	public void calling() {
		System.out.println("airtel calling");
		System.out.println("charges per month" + chargesPerMonth);
		
	}

	@Override
	public void data() {
		System.out.println("airtel data");
	}

	public Airtelsim(float chargesPerMonth) {
		super();
		this.chargesPerMonth = chargesPerMonth;
	}
	public Airtelsim() {
		super();
	}
 
	public float getChargesPerMonth() {
		return chargesPerMonth;
	}

	public void setChargesPerMonth(float chargesPerMonth) {
		this.chargesPerMonth = chargesPerMonth;
	}

	

}
