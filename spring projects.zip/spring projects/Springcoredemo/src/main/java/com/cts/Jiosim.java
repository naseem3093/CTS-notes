package com.cts;

public class Jiosim implements Sim{
	private float chargesPerMonth;
	public float getChargesPerMonth() {
		return chargesPerMonth;
	}

	public void setChargesPerMonth(float chargesPerMonth) {
		this.chargesPerMonth = chargesPerMonth;
	}

	@Override
	public void calling() {
		System.out.println("jio calling");
		System.out.println("charges per month" + chargesPerMonth);
		
	}

	public Jiosim(float chargesPerMonth) {
		super();
		this.chargesPerMonth = chargesPerMonth;
	}
	public Jiosim() {
		super();
	}

	@Override
	public void data() {
		System.out.println("jio data");
		
	}

}
