package com.cts;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class Mobile 
{
    public static void main( String[] args )
    {
      ApplicationContext context=new ClassPathXmlApplicationContext("new.xml");
      Sim airtel=(Sim) context.getBean("airtel", Sim.class);
      System.out.println(airtel);
      airtel.calling();
      airtel.data();
      Sim jio=context.getBean("jio", Sim.class);
      System.out.println(jio);
      jio.calling();
      jio.data();
    }
}
