package com.cts;

public interface Sim {
	void calling();
	
	void data();
	
}
