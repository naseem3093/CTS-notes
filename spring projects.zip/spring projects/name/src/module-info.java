/**
 * 
 */
/**
 * 
 */
module name {
	requires java.sql;
}