package name;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class demo {
	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cts","root","password-1");
		System.out.println("Connection created "+conn);
		Statement stmt=conn.createStatement();
		stmt.execute("create table mobiles(mobileid int,mobilename varchar(20),price decimal(7,2))");
		conn.close();
		System.out.println("table created");
		
	}
}
