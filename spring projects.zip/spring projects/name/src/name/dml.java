package name;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class dml {
	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cts","root","password-1");
		System.out.println("Connection created "+conn);
		Statement stmt=conn.createStatement();
		//int result=stmt.executeUpdate("insert into mobiles values(1,'samsung',2323)");
		
		//int result=stmt.executeUpdate("update mobiles set price=price+500");
		int result=stmt.executeUpdate("delete from mobiles where mobileid=1");
		conn.close();
		System.out.println(result+"rows deleted");
		
	}
}
