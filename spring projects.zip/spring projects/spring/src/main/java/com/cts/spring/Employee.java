package com.cts.spring;

public class Employee {
	private int empID;
	private String empName;
	private int empsal;
	private String empDesg;

	public int getEmpID() {
		return empID;
	}

	public void setEmpID(int empID) {
		this.empID = empID;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpsal() {
		return empsal;
	}

	public void setEmpsal(int empsal) {
		this.empsal = empsal;
	}

	public String getEmpDesg() {
		return empDesg;
	}

	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}
	
	public Employee(int empID, String empName, int empsal, String empDesg) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.empsal = empsal;
		this.empDesg = empDesg;
	}
	
	public Employee() {
		System.out.println("Default constructor");
	}
}
