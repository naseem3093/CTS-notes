package com.cts.repository;
import org.springframework.jdbc.core.JdbcTemplate;
import com.cts.model.Employee;

public class EmployeeRepositoryImpl implements EmpolyeeRepository {
	
	private JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		String sql="INSERT INTO employees (id,name,department,salary) VALUES(?,?,?,?)";
		int result=jdbcTemplate.update(sql,employee.getId(),employee.getName(),employee.getDepartment(),employee.getSalary());
		if(result>0)
			return "Employee Saved Successfully ";
		else
			return "something went wrong....";
	}
	
}
