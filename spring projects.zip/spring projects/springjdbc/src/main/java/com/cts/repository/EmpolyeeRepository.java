package com.cts.repository;

import com.cts.model.Employee;

public interface EmpolyeeRepository {
	public abstract String addEmployee(Employee employee);

}
