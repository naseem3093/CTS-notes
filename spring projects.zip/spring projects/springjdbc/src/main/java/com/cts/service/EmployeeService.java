package com.cts.service;

import com.cts.model.Employee;

public interface EmployeeService {
	public abstract String addEmployee(Employee employee);

}
