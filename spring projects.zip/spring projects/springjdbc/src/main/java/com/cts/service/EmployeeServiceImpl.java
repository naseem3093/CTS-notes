package com.cts.service;
 
import com.cts.model.Employee;
import com.cts.repository.EmployeeRepositoryImpl;
 
public class EmployeeServiceImpl implements EmployeeService {
	EmployeeRepositoryImpl repository;
	@Override
	public String addEmployee(Employee employee) {
		return repository.addEmployee(employee);
	}
	public EmployeeRepositoryImpl getRepository() {
		return repository;
	}
	public void setRepository(EmployeeRepositoryImpl repository) {
		this.repository = repository;
	}
}