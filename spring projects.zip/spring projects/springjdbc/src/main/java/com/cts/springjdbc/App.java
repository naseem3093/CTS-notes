package com.cts.springjdbc;
 
import java.util.Scanner;
 
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
 
import com.cts.model.Employee;
import com.cts.service.EmployeeServiceImpl;
 
/**
* Hello world!
*
*/
public class App
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("springconfig.xml");
        EmployeeServiceImpl service =context.getBean("employee",EmployeeServiceImpl.class);
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Employee Id : ");
        int empId=sc.nextInt();
        System.out.println("Enter Employee Name : ");
        String empName=sc.next();
        System.out.println("Enter Employee Department : ");
        String empDept=sc.next();
        System.out.println("Enter Employee Salary : ");
        float empSal=sc.nextFloat();
        Employee emp=new Employee(empId,empName,empDept,empSal);
        System.out.println(service.addEmployee(emp));
    }
}